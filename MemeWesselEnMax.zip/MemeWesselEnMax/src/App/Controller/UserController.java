package App.Controller;

import App.Model.Database;
import App.Model.User;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;

import java.sql.ResultSet;

import java.util.ArrayList;

public class UserController
{
    public TextField txtId;
    public Button btnToonUser;
    public TextField txtUserId;
    public TextField txtUserUsername;
    public TextField txtUserPassword;

    public void toonUser (ActionEvent actionEvent)
    {
        int id = Integer.parseInt(txtId.getText());
        User user = getUserById(id);
        txtUserId.setText(user.getID() + "");
        txtUserUsername.setText(user.getUsername());
        txtUserPassword.setText(user.getPassword());
    }

    public User getUserById(int id)
    {
        User user = new User();
        user.setId(id);

        Database db = new Database();
        db.connect();
        try
        {
            ResultSet rs = db.get("SELECT * FROM users WHERE id = " + user.getID() + ";");
            while(rs.next())
            {
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
            }
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
        return user;
    }

    public User getUser(String username, String password)
    {
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);

        Database db = new Database();
        db.connect();
        try
        {
            ResultSet rs = db.get("SELECT * FROM users WHERE username = '" + user.getUsername() + "' AND password ='"+ user.getPassword()+"';");
            while(rs.next())
            {
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
            }
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
        return user;
    }

    public ArrayList<User> getAllUsers()
    {
        ArrayList<User> users = new ArrayList<User>();

        Database db = new Database();
        db.connect();
        try
        {
            ResultSet rs = db.get("SELECT * FROM users");
            while(rs.next())
            {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));

                users.add(user);
            }
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }

        return users;
    }


}


