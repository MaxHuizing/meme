package App.Controller;
import App.Model.Database;
import javafx.event.ActionEvent;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javafx.stage.FileChooser;
import java.io.*;
import java.net.*;

public class UploadController
{
    public ImageView imgMeme;
    public File uploadFile;

    public void kiesMeme (ActionEvent actionEvent)
    {
        FileChooser fileChooser = new FileChooser();

        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
                new FileChooser.ExtensionFilter("All Files", "*.*")
        );

        File selectedFile = fileChooser.showOpenDialog(null);

        if(selectedFile != null){
            Image image = new Image(selectedFile.toURI().toString());
            imgMeme.setImage(image);

            uploadFile = selectedFile;
        }
    }

    public void uploadMeme (ActionEvent actionEvent)
    {
        String ftpUrl = "";
        String host = "185.104.29.78";
        String user = "mhuizing";
        String pass = "Meme";

        String filePath = uploadFile.getAbsolutePath();
        String uploadPath = "/domains/mhuizing.gcmsi.nl/public_html/Meme/images" + uploadFile.getName();

        ftpUrl = String.format(ftpUrl, user, pass, host, uploadPath);
        System.out.println("Upload URL: " + ftpUrl);

        try
        {
            URL url = new URL(ftpUrl);
            URLConnection conn = url.openConnection();
            OutputStream outputStream = conn.getOutputStream();
            FileInputStream inputStream = new FileInputStream(filePath);

            byte[] buffer = new byte[4096];
            int bytesRead = -1;
        while ((bytesRead = inputStream.read(buffer)) != -1)
        {
            outputStream.write(buffer, 0, bytesRead);
        }

        inputStream.close();
        outputStream.close();

        System.out.println("File uploaded");
        }catch (IOException ex) {
            ex.printStackTrace();
        }
    }


}
