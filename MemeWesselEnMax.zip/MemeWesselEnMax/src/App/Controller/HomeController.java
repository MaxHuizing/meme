package App.Controller;

import App.Model.Database;
import App.Model.Meme;
import App.Model.User;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.util.ArrayList;

public class HomeController
{
    public ArrayList<Meme> Meme = new ArrayList<>();
    public AnchorPane Memepane;
    public Button btnUploadMeme;
    public Button btnMemes;

    public void initialize()
    {

    }

    public void Memes (ActionEvent actionEvent)
    {
        getAlleMemes();
        //toonAfbeeldingAlleMemes();
    }

    public void getAlleMemes()
    {
        try
        {
            Database db = new Database();
            db.connect();

            ResultSet result = db.get("SELECT * FROM Memes");
            while (result.next())
            {
                Meme meme = new Meme();
                meme.setId(result.getInt("id"));
                meme.settitel(result.getString("titel"));
                meme.setURL(result.getString("URL"));

                meme.add(meme);
            }
            db.disconnect();
        } catch (Exception e)
        {
            System.out.println(e.getMessage());
        }

    }

    public void naarUpload (ActionEvent actionEvent)
    {


        try
        {
            Parent root = FXMLLoader.load(getClass().getResource("../View/UploadView.fxml"));
            Stage primaryStage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            primaryStage.setTitle("meme");
            primaryStage.setScene(new Scene(root));
            primaryStage.setFullScreenExitHint("");
            primaryStage.setFullScreen(true);
            primaryStage.show();
        } catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }




}



