
package App.Controller;
        import App.Model.User;
        import javafx.event.ActionEvent;
        import javafx.fxml.FXMLLoader;
        import javafx.scene.Node;
        import javafx.scene.Parent;
        import javafx.scene.Scene;
        import javafx.scene.control.Label;
        import javafx.scene.control.PasswordField;
        import javafx.scene.control.TextField;
        import javafx.stage.Stage;


public class LoginController
{

    public Label lbl_FoutInloggen;
    public Label lbl_Controlleer;
    public TextField txtPassword;
    public TextField txtname;

    public void txtlogin(ActionEvent actionEvent)
    {
        UserController uc = new UserController();
        System.out.println(txtname.getText() + " " + txtPassword.getText());
        User gebruiker = uc.getUser(txtname.getText(), txtPassword.getText());

        System.out.println("ID: "+gebruiker.getID());
        System.out.println("Gebruikersnaam: "+gebruiker.getUsername());
        System.out.println("Password: "+gebruiker.getPassword());

        if(gebruiker.getID()==0)
        {
            System.out.println("foei");
            //   lbl_FoutInloggen.setText("Inloggen mislukt.");
            //  lbl_Controlleer.setText("Controleer gebruikersnaam en wachtwoord.");
        }
        else
        {
            //    lbl_FoutInloggen.setText("");
            //  lbl_Controlleer.setText("");
            System.out.println("Ingelogd");
        }

        try
        {
            Parent root = FXMLLoader.load(getClass().getResource("../View/MemeView.fxml"));
            Stage primaryStage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            primaryStage.setTitle("meme");
            primaryStage.setScene(new Scene(root));
            primaryStage.setFullScreenExitHint("");
            primaryStage.setFullScreen(true);
            primaryStage.show();
        } catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

}
