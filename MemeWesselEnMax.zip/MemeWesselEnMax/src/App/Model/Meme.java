package App.Model;
public class Meme
{

    private String URL;
    private String titel;
    private int id;
    private String add;

    public void setURL(String url)
    {
        this.URL = url;
    }

    public String getURL()
    {
        return URL;
    }

    public void settitel(String titel)
    {
        this.titel = titel;
    }

    public String gettitel()
    {
        return titel;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Integer getId()
    {
        return id;
    }

    public void add(Meme meme)
    {
        this.add = add;
    }

    public String add()
    {
        return add;
    }
}
